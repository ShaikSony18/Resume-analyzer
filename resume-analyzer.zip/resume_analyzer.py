import openai
from prompt_templates import ATS_PROMPT_TEMPLATE

# Set your OpenAI API key
openai.api_key = "your-api-key-here"

def read_resume(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return file.read()

def generate_feedback(resume_text):
    prompt = ATS_PROMPT_TEMPLATE.format(resume=resume_text)
    
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an ATS resume evaluator."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=800,
        temperature=0.5
    )
    
    return response['choices'][0]['message']['content']

if __name__ == "__main__":
    resume_path = "sample_resume.txt"
    resume_text = read_resume(resume_path)
    feedback = generate_feedback(resume_text)
    
    print("=== ATS Resume Feedback ===")
    print(feedback)
