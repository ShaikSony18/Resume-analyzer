# AI-Powered Resume Analyzer (Prompt Engineering)

This project uses OpenAI's GPT model to simulate an ATS (Applicant Tracking System) to analyze resumes.

## Features
- Reads resume from a text file
- Applies structured prompt engineering
- Returns detailed ATS-style feedback

## Requirements
- Python 3.8+
- `openai` library

## How to Run

```bash
pip install openai
python resume_analyzer.py
```

## Prompt Engineering
Uses zero-shot and chain-of-thought prompting to simulate an ATS and return improvement feedback.

## Note
Replace `"your-api-key-here"` with your actual OpenAI API key.
