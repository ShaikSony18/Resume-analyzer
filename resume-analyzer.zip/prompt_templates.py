ATS_PROMPT_TEMPLATE = """
Analyze the following resume like an Applicant Tracking System (ATS) and provide feedback on:
1. Keyword optimization for software development roles.
2. Structure and formatting.
3. Missing key sections.
4. Suggestions to improve chances of selection.

Resume:
{resume}
"""
